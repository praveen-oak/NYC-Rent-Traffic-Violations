Run the following commands in terminal
chmod 755 run_profiling.sh
./run_profiling.sh

The max and min values will be stored in hdfs in folder
/user/ppo208/project/2009_01_profile{{ name of attribute that is profiled }}