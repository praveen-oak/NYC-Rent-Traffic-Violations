years = ['2018']
months = ['01']
hdfs_folder_path = "/user/ppo208/project/raw_data/"
hdfs_cleaned_data_folder_path = "/user/ppo208/project/clean_data/"
temp_folder = "/tmp/ppo208/"
base_url = 'https://s3.amazonaws.com/nyc-tlc/trip+data/yellow_tripdata_'